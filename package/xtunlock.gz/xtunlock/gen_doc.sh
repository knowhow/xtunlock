docco LICENSE_CPAL_bring.out_knowhow.md README.md CHANGELOG.md client/scripts/*.js
