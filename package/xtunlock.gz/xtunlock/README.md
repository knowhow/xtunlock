knowhow/xtuple paket "xtunlock"
====================================

Info
----

Paket otključava MultiWhs feature.

Instalacija
------------

Pakovanje se vrši na sljedeći način: 

<pre>
$ cd package
$ ./make_pkg.sh
</pre>

Sobijeni .gz sa updater-om instaliramo na knowhow/xtuple.
