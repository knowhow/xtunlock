0.0.0, vsasa, početak

----------------------------

Contributor(s):

* vsasa - Saša Vranić, sasa.vranic@bring.out.ba
* hernad - Ernad Husremović, ernad.husremovic@bring.out.ba
* bjasko - Jasmin Beganović, jasmin.beganovic@bring.out.ba
